﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossKnightController : MonoBehaviour
{
    
    public GameObject Shockwave;
    public Animator animator;
    private SpriteRenderer spriteRenderer;
    public float speed = 50.0f;
    public int health = 3;

    private Rigidbody2D rb;

    private void Start()
    {
        //Kalla í allt svo það sé hægt að nota þá seinna
        spriteRenderer = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
        rb = this.GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        //Sný riddaranum við
        var xScale = this.transform.localScale.x;

        if (this.transform.position.x <= -23)
        {
            Drill();
        }
        if (this.transform.position.x >= 23)
        {
            if (rb.velocity.x > 1)
            {
                spriteRenderer.flipX = false;
                rb.velocity = new Vector2(0, 0);
                AddCount();
                PlayHit();
            }
        }
        //Læt riddarann deyja
        if (health <= 0)
        {
            animator.Play("BossKnight_Death");
        }
    }
    //Birti höggbylgju eftir að riddarinn sveiflar sverðinu
    public void SpawnShockwave()
    {
        GameObject a = Instantiate(Shockwave) as GameObject;
        a.transform.position = new Vector2(20, -5);
    }
    //Læt riddarann fara í óstoppanlegt stökk fram og aftur sem við köllum drill
    public void Drill()
    {
        animator.Play("BossKnight_Drill");
        if (this.transform.position.x > -23)
        {
            rb.velocity = new Vector2(-speed, 0);
        } else if (this.transform.position.x <= -23)
        {
            spriteRenderer.flipX = true;
            rb.velocity = new Vector2(speed, 0);
        }
    }
    //Læt riddarann gera sérstakar árásir eða standa kyrr
    private void PlayHit()
    {
        int count = animator.GetInteger("Count");
        if (count < 3)
        {
            animator.Play("BossKnight_Hit");
        }
        else if (count == 3)
        {
            animator.Play("BossKnight_Idle");
            AddCount();
        }
        else if (count == 4)
        {
            animator.Play("BossKnight_DrillStance");
        }
        else if (count == 5)
        {
            animator.Play("BossKnight_Idle");
            AddCount();
        }
        else
        {
            animator.SetInteger("Count", 0);
            PlayHit();
        }
    }
    //Bæti við 1 í talninguna
    public void AddCount()
    {
        int count = animator.GetInteger("Count");
        animator.SetInteger("Count", count + 1);
    }

    //Læt riddarann eyða sjálfum sér
    public void DestroySelf()
    {
        Destroy(this.gameObject);
    }

    //Læt riddarann taka skaða
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Hit")
        {
            health -= 1;
        }
    }
}