﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlyingEnemyScript : MonoBehaviour
{
    public Rigidbody2D rb;
    public float enemySpeed = 20.0f;
    

    // Update is called once per frame
    void FixedUpdate()
    {
        //Læt fljúgandi óvini hreyfast til vinstri
        rb.AddForce(new Vector2(-enemySpeed * Time.deltaTime, 0f));
    }

}
