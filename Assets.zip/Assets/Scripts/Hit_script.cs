﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hit_script : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collisionInfo)
    {
        //Eyðir öllu sem hefur merkið Bad sem er lamið af prikinu hjá leikmanninum
        if (collisionInfo.collider.tag == "Bad")
        {
            Destroy(collisionInfo.gameObject);
        }
    }
}
