﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovements : MonoBehaviour
{

    public CharacterController controller;
    public Animator animator;

    public GameObject HitRange;

    public float runSpeed = 40f;

    float horizontalMove = 0f;
    bool jump = false;
    bool crouch = false;

    private void Start()
    {
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {

        horizontalMove = Input.GetAxisRaw("Horizontal") * runSpeed;

        animator.SetFloat("Speed", Mathf.Abs(horizontalMove));

        if (Input.GetKeyDown(KeyCode.W))
        {
            jump = true;
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            Attack();
        }

        var listi = GameObject.FindGameObjectsWithTag("Hit");
        if (listi.Length > 1)
        {
            Destroy(GameObject.FindGameObjectWithTag("Hit"));
        }
    }

    void FixedUpdate()
    {
        // Move our character
        controller.Move(horizontalMove * Time.fixedDeltaTime, crouch, jump);
        jump = false;
    }

    void Attack()
    {
        animator.Play("Player_Hit");
        GameObject a = Instantiate(HitRange) as GameObject;
        if (this.transform.localScale.x > 0)
        {
            a.transform.position = new Vector2(this.transform.position.x + 1, this.transform.position.y);
        } else
        {
            a.transform.position = new Vector2(this.transform.position.x - 1, this.transform.position.y);
        }
        
    }
    void AttackOff()
    {
        Destroy(GameObject.FindGameObjectWithTag("Hit"));
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Bad" || collision.collider.tag == "BossMan" || collision.collider.tag == "OutOfBounds")
        {
            Destroy(this.gameObject);
            SceneManager.LoadScene("Level1");
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
}