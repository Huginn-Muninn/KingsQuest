﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovements : MonoBehaviour
{

    public CharacterController controller;
    public Animator animator;//virkaði ekki án neðra

    public GameObject HitRange;

    public float runSpeed = 40f;

    float horizontalMove = 0f;
    bool jump = false;
    bool crouch = false;

    private void Start()
    {
        //Læt animatorinn virka því ekkert var að virka með efra
        animator = GetComponent<Animator>();
    }

   
    void Update()
    {
        //Lætur leikmaninn hlaupa/labba
        horizontalMove = Input.GetAxisRaw("Horizontal") * runSpeed;

        animator.SetFloat("Speed", Mathf.Abs(horizontalMove));
        //lætur leikmanninn hoppa
        if (Input.GetKeyDown(KeyCode.W))
        {
            jump = true;
        }
        //Lætur leikmanninn gera árás
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Attack();
        }
        //Eyðileggur lítið hitbox fyrir framan leikmanninn sem er akkúrat allt animationið á stærð til að fá betri árás
        var listi = GameObject.FindGameObjectsWithTag("Hit");
        if (listi.Length > 1)
        {
            Destroy(GameObject.FindGameObjectWithTag("Hit"));
        }
    }

    void FixedUpdate()
    {
        // Hreyfir leikmanninn
        controller.Move(horizontalMove * Time.fixedDeltaTime, crouch, jump);
        jump = false;
    }

    void Attack()
    {
        //Gerir árás og birtir hitbox
        animator.Play("Player_Hit");
        GameObject a = Instantiate(HitRange) as GameObject;
        if (this.transform.localScale.x > 0)
        {
            a.transform.position = new Vector2(this.transform.position.x + 1, this.transform.position.y);
        } else
        {
            a.transform.position = new Vector2(this.transform.position.x - 1, this.transform.position.y);
        }
        
    }
    void AttackOff()
    {
        //Eyðir hitboxið
        Destroy(GameObject.FindGameObjectWithTag("Hit"));
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        //Lætur allt með merkið Bad drepa leikmanninn
        if (collision.collider.tag == "Bad" || collision.collider.tag == "BossMan" || collision.collider.tag == "OutOfBounds")
        {
            Destroy(this.gameObject);
            //Birtir leikmanninn aftur á fyrsta borðinu
            SceneManager.LoadScene("Level1");
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //Finnur hvaða sena er í gangi og lætur svo næstu í gang þegar það er farið inn í triggerinn
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
}