﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    public BossKnightController boss;
    public Text healthText;

    // Update is called once per frame
    void Update()
    {
        healthText.text = boss.health.ToString();
    }
}
